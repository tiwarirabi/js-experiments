function AntSmasher(elem){
    this.element = elem;
    this.width;
    this.height;

    this.ants = [];

    this.intervalRef;

    this.score = 0;
    this.scoreBoard = undefined;

    var self = this;

    var dieSound = undefined;

    this.initRadius = undefined;
    this.initNoOfAnts = undefined;
    
    this.setScreen = function(elem){
        this.element = elem;
    }

    this.startGame = function(){
        this.score =0;
        this.ants = [];
        for(var i = 0; i<this.initNoOfAnts; i++)
            this.createAnt(this.initRadius);
        
    }

    this.setDimensions = function(width,height){
        this.width = width;
        this.height = height;

        this.element.style.width = this.width + "px";
        this.element.style.height = this.height + "px";
        this.element.style.overflow = "hidden";
    }

    this.createAnt = function(radius){
        var newAnt = new Ant();
        newAnt.init(this.element,this.width,this.height,radius);
        newAnt.setScoreUpdateCallBack(this.antClicked);
        newAnt.setAntDiedCallBack(this.removeAnt);
        this.ants.push(newAnt);
    }

    this.updateAnts = function(){
        if(this.ants.length==0){
            this.startGame();
        }
        this.ants.forEach((singleAnt)=>{
            singleAnt.move();
        });
        this.checkAntCollision();
    }

    this.antClicked = function(whichAnt){
        self.score++;
        self.scoreBoard.updateScore(self.score);
        self.removeAnt(whichAnt);
    }

    this.removeAnt =function(whichAnt){
        whichAnt.element.style.display = "none";
        whichAnt.element.remove();
        self.ants.splice(self.ants.indexOf(whichAnt),1);

       /* self.ants = self.ants.filter((ant)=>{
            return self.ants.indexOf(whichAnt) > -1;
        });
*/
        self.dieSound.play();
        //whichAnt.removeAnt();
    }

    this.checkAntCollision = function(){
        this.ants.forEach((singleAnt)=>{
            antCenter = singleAnt.getCenter();
            this.ants.forEach((singleAnt2)=>{
                if(singleAnt != singleAnt2){
                    ant2Center = singleAnt2.getCenter();
                    if(this.getDistanceTo(antCenter,ant2Center) <= singleAnt.radius + singleAnt2.radius){
                        //console.log(antCenter,ant2Center,this.getDistanceTo(antCenter,ant2Center));
                        
                        var ant1Degree = singleAnt.degree;
                        var ant2Degree = singleAnt2.degree;
                        
                        singleAnt.changeDegree(ant2Degree);
                        singleAnt.decreaseLife();

                        singleAnt2.changeDegree(ant1Degree);
                        singleAnt2.decreaseLife();
                    }
                }
            });
        });
    }

    

    this.getDistanceTo =function(point1,point2){
        return Math.sqrt(Math.pow(point1.x-point2.x,2)+Math.pow(point1.y-point2.y,2));
    }

    this.init = function(noOfAnts,radius){

        this.initRadius = radius;
        this.initNoOfAnts = noOfAnts;
        
        this.startGame();
        
        this.dieSound = new GameSound('dieSound.mp3');

        this.scoreBoard = new ScoreBoard();
        this.scoreBoard.init(this.element)
        
        this.intervalRef = setInterval(() => this.updateAnts(),20);
    }


    


}