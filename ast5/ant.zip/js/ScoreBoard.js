function ScoreBoard(){
    this.score = 0;
    this.element = undefined;

    this.staticElement = undefined;
    this.dynamicElement = undefined;

    this.parent = undefined;

    this.init = function(parent){
        this.parent = parent;


        var elem = document.createElement('div');
        elem.style.height = 40 + "px";
        elem.style.width = 150 + "px";
        elem.style.borderRadius = "10px";
        elem.style.backgroundColor = "rgba(255,255,255,0.7)";
        elem.style.position = "absolute";
        elem.style.left = "50%";
        elem.style.marginLeft = "-100px";
        elem.style.top = 20 + "px";

        this.element = elem;

        this.parent.appendChild(elem);

        var staticElem = document.createElement('span');
        staticElem.style.lineHeight = 40 + "px";
        staticElem.style.display = "inline-block";
        staticElem.style.borderRadius = "10px 0px 0px 10px";
        staticElem.style.backgroundColor = "rgba(255,255,255,0.9)";
        staticElem.style.padding = "0px 10px";
        staticElem.innerHTML = "SCORE";

        this.staticElement = staticElem;

        this.element.appendChild(staticElem);

        var dynamicElem = document.createElement('span');
        dynamicElem.style.lineHeight = 40 + "px";
        dynamicElem.style.display = "inline-block";
        dynamicElem.style.padding = "0px 10px";
        dynamicElem.innerHTML = this.score;
        dynamicElem.style.fontSize = "30px";
        dynamicElem.style.fontWeight = "bold";

        this.dynamicElement = dynamicElem;

        this.element.appendChild(dynamicElem);

        
    }

    this.updateScore = function(newScore){
        this.score = newScore;
        this.dynamicElement.innerHTML = this.score;
    }
}